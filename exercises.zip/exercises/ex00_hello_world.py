"""My first program for COMP110."""
__author__ = "730617586"
print("Hello, world.")
print("Hello, unc world.")